package test1;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestDateEntry {
	
	Testjar test1 = new Testjar();
	@Test
	public void test() {
		assertEquals(true, test1.checkDate("jan-2018"));
		assertEquals(false, test1.checkDate("01-2018"));
		assertEquals(false, test1.checkDate("0-2018"));
		assertEquals(false, test1.checkDate(""));
		assertEquals(true, test1.checkDate("jan-2028"));
		assertEquals(true, test1.checkDate("jan-2029"));
		
	}

}
