package test1;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

public class testDataProcessed {
	
	Testjar test1 = new Testjar();
	String testURL1 = "https://eservices.mas.gov.sg/api/action/datastore/search.json?resource_id=5f2b18a8-0883-4769-a635-879c63d3caac&between[end_of_month]=2018-01,2018-07";
	
	String testURL2 = "https://eservices.mas.gov.sg/api/action/datastore/search.json?resource_id=5f2b18a8-0883-4769-a635-879c63d3caac&between[end_of_month]=2018-07,2018-08";
	//String rawData = "[{"end_of_month":"2018-01","prime_lending_rate":"5.33","banks_fixed_deposits_3m":"0.15","banks_fixed_deposits_6m":"0.22","banks_fixed_deposits_12m":"0.34","banks_savings_deposits":"0.16","fc_hire_purchase_motor_3y":"5.02","fc_housing_loans_15y":"3.16","fc_fixed_deposits_3m":"0.30","fc_fixed_deposits_6m":"0.38","fc_fixed_deposits_12m":"0.50","fc_savings_deposits":"0.17","timestamp":"1552739091"},{"end_of_month":"2018-02","prime_lending_rate":"5.33","banks_fixed_deposits_3m":"0.15","banks_fixed_deposits_6m":"0.22","banks_fixed_deposits_12m":"0.34","banks_savings_deposits":"0.16","fc_hire_purchase_motor_3y":"5.02","fc_housing_loans_15y":"3.16","fc_fixed_deposits_3m":"0.30","fc_fixed_deposits_6m":"0.38","fc_fixed_deposits_12m":"0.50","fc_savings_deposits":"0.17","timestamp":"1552739091"},{"end_of_month":"2018-03","prime_lending_rate":"5.33","banks_fixed_deposits_3m":"0.15","banks_fixed_deposits_6m":"0.22","banks_fixed_deposits_12m":"0.34","banks_savings_deposits":"0.16","fc_hire_purchase_motor_3y":"5.02","fc_housing_loans_15y":"3.16","fc_fixed_deposits_3m":"0.30","fc_fixed_deposits_6m":"0.38","fc_fixed_deposits_12m":"0.50","fc_savings_deposits":"0.17","timestamp":"1552739091"},{"end_of_month":"2018-04","prime_lending_rate":"5.33","banks_fixed_deposits_3m":"0.15","banks_fixed_deposits_6m":"0.22","banks_fixed_deposits_12m":"0.34","banks_savings_deposits":"0.16","fc_hire_purchase_motor_3y":"4.83","fc_housing_loans_15y":"3.16","fc_fixed_deposits_3m":"0.30","fc_fixed_deposits_6m":"0.38","fc_fixed_deposits_12m":"0.50","fc_savings_deposits":"0.17","timestamp":"1552739091"},{"end_of_month":"2018-05","prime_lending_rate":"5.33","banks_fixed_deposits_3m":"0.15","banks_fixed_deposits_6m":"0.22","banks_fixed_deposits_12m":"0.37","banks_savings_deposits":"0.16","fc_hire_purchase_motor_3y":"4.83","fc_housing_loans_15y":"3.16","fc_fixed_deposits_3m":"0.30","fc_fixed_deposits_6m":"0.38","fc_fixed_deposits_12m":"0.50","fc_savings_deposits":"0.17","timestamp":"1552739091"},{"end_of_month":"2018-06","prime_lending_rate":"5.33","banks_fixed_deposits_3m":"0.15","banks_fixed_deposits_6m":"0.22","banks_fixed_deposits_12m":"0.37","banks_savings_deposits":"0.16","fc_hire_purchase_motor_3y":"4.83","fc_housing_loans_15y":"3.16","fc_fixed_deposits_3m":"0.30","fc_fixed_deposits_6m":"0.38","fc_fixed_deposits_12m":"0.50","fc_savings_deposits":"0.17","timestamp":"1552739091"},{"end_of_month":"2018-07","prime_lending_rate":"5.33","banks_fixed_deposits_3m":"0.16","banks_fixed_deposits_6m":"0.23","banks_fixed_deposits_12m":"0.38","banks_savings_deposits":"0.16","fc_hire_purchase_motor_3y":"4.83","fc_housing_loans_15y":"3.16","fc_fixed_deposits_3m":"0.30","fc_fixed_deposits_6m":"0.38","fc_fixed_deposits_12m":"0.50","fc_savings_deposits":"0.17","timestamp":"1552739091"},{"end_of_month":"2018-08","prime_lending_rate":"5.33","banks_fixed_deposits_3m":"0.16","banks_fixed_deposits_6m":"0.23","banks_fixed_deposits_12m":"0.40","banks_savings_deposits":"0.16","fc_hire_purchase_motor_3y":"4.83","fc_housing_loans_15y":"3.16","fc_fixed_deposits_3m":"0.30","fc_fixed_deposits_6m":"0.38","fc_fixed_deposits_12m":"0.50","fc_savings_deposits":"0.17","timestamp":"1552739091"}]";

	
	@Test
	public void test() {
		String jsonStr = test1.sendRequest(testURL1);
		assertTrue(jsonStr.contains("2018-01"));
		assertTrue(jsonStr.contains("banks_fixed_deposits_3m"));
		assertTrue(jsonStr.contains("fc_fixed_deposits_3m"));
		assertTrue(jsonStr.contains("banks_fixed_deposits_3m"));
		assertEquals(7, test1.list.size());
		assertEquals("2018-01", test1.list.get(0).end_of_month);
		assertEquals("2018-06", test1.list.get(5).end_of_month);

		
		String jsonStr2 = test1.sendRequest(testURL2);
		assertTrue(jsonStr2.contains("2018-07"));
		assertTrue(jsonStr2.contains("banks_fixed_deposits_3m"));
		assertTrue(jsonStr2.contains("fc_fixed_deposits_3m"));
		assertTrue(jsonStr2.contains("banks_fixed_deposits_3m"));
		assertEquals(2, test1.list.size());
		assertEquals("2018-07", test1.list.get(0).end_of_month);
	}

}
