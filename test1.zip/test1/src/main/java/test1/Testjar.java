package test1;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import com.google.gson.Gson; 
import com.google.gson.reflect.TypeToken;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import test1.Record;

public class Testjar {
	
static List<Record> list;
	
	
	static String baseURL = "https://eservices.mas.gov.sg/api/action/datastore/search.json?resource_id=5f2b18a8-0883-4769-a635-879c63d3caac&between[end_of_month]=";
//	static String url = "https://eservices.mas.gov.sg/api/action/datastore/search.json?resource_id=5f2b18a8-0883-4769-a635-879c63d3caac&between[end_of_month]=2008-01,2010-12";
	
	public static void main(String[] args){
		Date dateFrom=null;
		Date dateTo=null;
		String dateStr="";
		
		dateStr=enterDate ("FROM");
		
		dateFrom=getDate(dateStr);
		System.out.println("You have entered date FROM as "+dateFrom);
		
		dateStr=enterDate ("TO");
		
		dateTo=getDate(dateStr);
		System.out.println("You have entered date FROM as "+dateTo);
		
	    setQuery(dateFrom, dateTo);   
	    
	    printRates();
	}
	
	public static String enterDate (String message){
		boolean retry=true;
		// Get input form user
		String dateStr="";
		while(retry){
			System.out.println("Enter date "+ message +" in MMM-yyyy:");
			Scanner myObj = new Scanner(System.in);
			dateStr= myObj.nextLine();
			// jan-2018

			if (dateStr.length()==8){
				if (checkDate(dateStr)){
					retry=false;
				} else {
					System.out.println("Wrong format - Enter date "+ message +" in MMM-yyyy:");
				}
			} else {
				System.out.println("Wrong format - Enter date "+ message +" in MMM-yyyy:");
			}
		
		}
		return dateStr;
	}
	
	public static void printRates(){
		
		double avg_banks_fixed_deposits_3m = 0.0;
		double avg_banks_fixed_deposits_6m = 0.0;
		double avg_banks_fixed_deposits_12m = 0.0;
		double avg_banks_savings_deposits = 0.0;
		
		double avg_fc_fixed_deposits_3m = 0.0;
		double avg_fc_fixed_deposits_6m = 0.0;
		double avg_fc_fixed_deposits_12m = 0.0;
		double avg_fc_savings_deposits = 0.0;
		
		List<Double> bankTrend = new ArrayList();
		List<Double> fcTrend = new ArrayList();
		
		System.out.println("Fixed Deposit 3m");
		System.out.println("Month		Bank	FC");
		
		for (Record record : list){
			
			System.out.println(record.end_of_month+"		"+record.banks_fixed_deposits_3m+"	"+record.fc_fixed_deposits_3m);
			// Calculate avg
			avg_banks_fixed_deposits_3m = Double.parseDouble(record.banks_fixed_deposits_3m)+avg_banks_fixed_deposits_3m;
			avg_fc_fixed_deposits_3m = Double.parseDouble(record.fc_fixed_deposits_3m) + avg_fc_fixed_deposits_3m;
			
			// Prepare data for trend 
			bankTrend.add(Double.parseDouble(record.banks_fixed_deposits_3m));
			fcTrend.add(Double.parseDouble(record.fc_fixed_deposits_3m));
		}
		System.out.println("\nAverage bank 3m interest rate " + avg_banks_fixed_deposits_3m/list.size());
		System.out.println("Average FC 3m interest rate " + avg_fc_fixed_deposits_3m/list.size());
		System.out.println("The 3m interest rate for bank is "+trend(bankTrend));
		System.out.println("The 3m interest rate for FC is "+trend(fcTrend));
		bankTrend.clear();
		fcTrend.clear();
		
		System.out.println("----------------------------------------------------------");
		
		System.out.println("Fixed Deposit 6m");
		System.out.println("Month		Bank	FC");
		
		for (Record record : list) {
			System.out.println(record.end_of_month+"		"+record.banks_fixed_deposits_6m+"	"+record.fc_fixed_deposits_6m);
			
			// Calculate avg
			avg_banks_fixed_deposits_6m = Double.parseDouble(record.banks_fixed_deposits_6m)+avg_banks_fixed_deposits_6m;
			avg_fc_fixed_deposits_6m = Double.parseDouble(record.fc_fixed_deposits_6m) + avg_fc_fixed_deposits_6m;
			
			// Prepare data for trend 
			bankTrend.add(Double.parseDouble(record.banks_fixed_deposits_6m));
			fcTrend.add(Double.parseDouble(record.fc_fixed_deposits_6m));
			
		}
		
		System.out.println("\nAverage bank 6m interest rate " + avg_banks_fixed_deposits_6m/list.size());
		System.out.println("Average FC 6m interest rate " + avg_fc_fixed_deposits_6m/list.size());
		System.out.println("The 6m interest rate for bank is "+trend(bankTrend));
		System.out.println("The 6m interest rate for FC is "+trend(fcTrend));
		bankTrend.clear();
		fcTrend.clear();
		System.out.println("----------------------------------------------------------");
		
		System.out.println("Fixed Deposit 12m");
		System.out.println("Month		Bank	FC");
		
		for (Record record : list){
			System.out.println(record.end_of_month+"		"+record.banks_fixed_deposits_12m+"	"+record.fc_fixed_deposits_12m);
			
			// Calculate avg
			
			avg_banks_fixed_deposits_12m = Double.parseDouble(record.banks_fixed_deposits_12m)+avg_banks_fixed_deposits_12m;
			avg_fc_fixed_deposits_12m = Double.parseDouble(record.fc_fixed_deposits_12m) + avg_fc_fixed_deposits_12m;
			
			// Prepare data for trend 
			bankTrend.add(Double.parseDouble(record.banks_fixed_deposits_12m));
			fcTrend.add(Double.parseDouble(record.fc_fixed_deposits_12m));
			
		}
		
		System.out.println("\nAverage bank 12m interest rate " + avg_banks_fixed_deposits_12m/list.size());
		System.out.println("Average FC 12m interest rate " + avg_fc_fixed_deposits_12m/list.size());
		System.out.println("The 12m interest rate for bank is "+trend(bankTrend));
		System.out.println("The 12m interest rate for FC is "+trend(fcTrend));
		bankTrend.clear();
		fcTrend.clear();
		
		System.out.println("----------------------------------------------------------");
		System.out.println("Savings Deposit");
		System.out.println("Month		Bank	FC");
		
		for (Record record : list){
			System.out.println(record.end_of_month+"		"+record.banks_savings_deposits+"	"+record.fc_savings_deposits);
			avg_banks_savings_deposits = Double.parseDouble(record.banks_savings_deposits)+avg_banks_savings_deposits;
			avg_fc_savings_deposits = Double.parseDouble(record.fc_savings_deposits) + avg_fc_savings_deposits;
			
			bankTrend.add(Double.parseDouble(record.banks_savings_deposits));
			fcTrend.add(Double.parseDouble(record.fc_savings_deposits));
			
		}
		
		System.out.println("\nAverage bank savings interest rate " + avg_banks_savings_deposits/list.size());
		System.out.println("Average FC savings interest rate " + avg_fc_savings_deposits/list.size());
		System.out.println("The savings rate for bank is "+trend(bankTrend));
		System.out.println("The savings rate for FC is "+trend(fcTrend));
		bankTrend.clear();
		fcTrend.clear();
	}
	public static void setQuery(Date dateFrom, Date dateTo){
		
		//Format date for API query
		String queryURL = baseURL;
		SimpleDateFormat mmyyformat = new SimpleDateFormat("yyyy-MM");
		String dateFrominQueryStr = mmyyformat.format(dateFrom);
		String dateToinQueryStr = mmyyformat.format(dateTo);
		
		System.out.println(dateFrominQueryStr);
		System.out.println(dateToinQueryStr);
		
		queryURL=baseURL+ dateFrominQueryStr+","+dateToinQueryStr;
		sendRequest(queryURL);
	}
	
	public static Date getDate (String dateStr) {
		
		SimpleDateFormat mmyyformat = new SimpleDateFormat("MMM-yyyy");
		Date date = null;
		

			try {
				mmyyformat.setLenient(false);
				date = mmyyformat.parse(dateStr);
				
			} catch (ParseException e) {
				
			}
			
			if (date != null) {
				
			}
			
			return date;
		
	}

	public static String sendRequest(String url) {
		
		System.out.println("URL sent to MAS for query "+url);
        String result = "";
        try {
        	
        	HttpClient client = HttpClientBuilder.create().build();
    		HttpGet request = new HttpGet(url);
    		
            request.setURI(new URI(url));
            HttpResponse response = client.execute(request);
            InputStream ips = response.getEntity().getContent();
            BufferedReader buf = new BufferedReader(new InputStreamReader(ips,"UTF-8"));
            StringBuilder sb = new StringBuilder();
            String s;
            
            String recordStr = "records";
            while (true) {
                s = buf.readLine();
                if (s == null || s.length() == 0)
                    break;
                sb.append(s);
            }
            buf.close();
            ips.close();
            result = sb.toString();
            
            
            int startOfRecord = result.indexOf(recordStr);
            // Trim away header for conversion to array of Record object
            result = result.substring(startOfRecord+9, result.length()-2);

            System.out.println("Result extracted " +result);
            Gson gson = new Gson();
            list = gson.fromJson(result, new TypeToken<List<Record>>(){}.getType());
            
          
     
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
	
	
	public static boolean checkDate(String inputDate) {
		if (inputDate.isEmpty()){
			return false;
		} else if (inputDate==null){
			return false;
		}
		
		SimpleDateFormat mmyyformat = new SimpleDateFormat("MMM-yyyy");
		Date date = null;
		boolean correctFormat = false;
		if(null == inputDate) {
			return false;
		}
		
			try {
				mmyyformat.setLenient(false);
				date = mmyyformat.parse(inputDate);
				
			} catch (ParseException e) {
				//Shhh.. try other formats
			}
			
			if (date != null) {
				correctFormat = true;
			}
			
			return correctFormat;

	}
	
	
	
	public static String trend(List<Double> fcTrend){
		
		String trendStr = "not increasing nor decreasing";
		int variable = fcTrend.size();
		int variableInitial = fcTrend.size();
		int diff = 0;
		
		for(int i=0; i<fcTrend.size()-1;i++)
	    {
			//System.out.println(fcTrend.get(i));
	        if(fcTrend.get(i)<fcTrend.get(i+1))
	        	
	            {
	        	variable++;
	            } else
	        if(fcTrend.get(i)>fcTrend.get(i+1))
            {
	        	variable--;
            } else if (fcTrend.get(i)==fcTrend.get(i+1)){
            	
            }
	    }

		diff = variableInitial-variable;
		if ( -2 > diff){
			trendStr = "Increasing";
			
		} else if ( 2 < diff) {
			trendStr = "Decreasing";
		}
		
		return trendStr;
	}
}
