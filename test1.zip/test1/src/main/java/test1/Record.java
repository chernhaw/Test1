package test1;

public class Record {

	String end_of_month = "";
	   
	String prime_lending_rate = "";
    String banks_fixed_deposits_3m = "";
    String banks_fixed_deposits_6m = "";
    String banks_fixed_deposits_12m = "";
    String banks_savings_deposits =  "";
    String fc_hire_purchase_motor_3y = "";
    String fc_housing_loans_15y = "";
    String fc_fixed_deposits_3m = "";
    String fc_fixed_deposits_6m = "";
    String fc_fixed_deposits_12m = "";
    String fc_savings_deposits = "";
    String timestamp = "";
	
    
    public String getEnd_of_month() {
		return end_of_month;
	}
	public void setEnd_of_month(String end_of_month) {
		this.end_of_month = end_of_month;
	}
	public String getPrime_lending_rate() {
		return prime_lending_rate;
	}
	public void setPrime_lending_rate(String prime_lending_rate) {
		this.prime_lending_rate = prime_lending_rate;
	}
	public String getBanks_fixed_deposits_3m() {
		return banks_fixed_deposits_3m;
	}
	public void setBanks_fixed_deposits_3m(String banks_fixed_deposits_3m) {
		this.banks_fixed_deposits_3m = banks_fixed_deposits_3m;
	}
	public String getBanks_fixed_deposits_6m() {
		return banks_fixed_deposits_6m;
	}
	public void setBanks_fixed_deposits_6m(String banks_fixed_deposits_6m) {
		this.banks_fixed_deposits_6m = banks_fixed_deposits_6m;
	}
	public String getBanks_fixed_deposits_12m() {
		return banks_fixed_deposits_12m;
	}
	public void setBanks_fixed_deposits_12m(String banks_fixed_deposits_12m) {
		this.banks_fixed_deposits_12m = banks_fixed_deposits_12m;
	}
	public String getBanks_savings_deposits() {
		return banks_savings_deposits;
	}
	public void setBanks_savings_deposits(String banks_savings_deposits) {
		this.banks_savings_deposits = banks_savings_deposits;
	}
	public String getFc_hire_purchase_motor_3y() {
		return fc_hire_purchase_motor_3y;
	}
	public void setFc_hire_purchase_motor_3y(String fc_hire_purchase_motor_3y) {
		this.fc_hire_purchase_motor_3y = fc_hire_purchase_motor_3y;
	}
	public String getFc_housing_loans_15y() {
		return fc_housing_loans_15y;
	}
	public void setFc_housing_loans_15y(String fc_housing_loans_15y) {
		this.fc_housing_loans_15y = fc_housing_loans_15y;
	}
	public String getFc_fixed_deposits_3m() {
		return fc_fixed_deposits_3m;
	}
	public void setFc_fixed_deposits_3m(String fc_fixed_deposits_3m) {
		this.fc_fixed_deposits_3m = fc_fixed_deposits_3m;
	}
	public String getFc_fixed_deposits_6m() {
		return fc_fixed_deposits_6m;
	}
	public void setFc_fixed_deposits_6m(String fc_fixed_deposits_6m) {
		this.fc_fixed_deposits_6m = fc_fixed_deposits_6m;
	}
	public String getFc_fixed_deposits_12m() {
		return fc_fixed_deposits_12m;
	}
	public void setFc_fixed_deposits_12m(String fc_fixed_deposits_12m) {
		this.fc_fixed_deposits_12m = fc_fixed_deposits_12m;
	}
	public String getFc_savings_deposits() {
		return fc_savings_deposits;
	}
	public void setFc_savings_deposits(String fc_savings_deposits) {
		this.fc_savings_deposits = fc_savings_deposits;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
}
